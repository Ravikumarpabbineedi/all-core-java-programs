import java.io.*;
class Basicprogram
{
	public static void main(String args[])
	{
		boolean a=false;
		System.out.println(!a);
	}
}
import java.io.*;
class Capitalornot
{
	public static void main(String args[])
	{
		char ch='R';
		int result;
		
		result=(ch>=65 && ch<=90)?1:0;

		System.out.println(result);
	}
}

		
		
		
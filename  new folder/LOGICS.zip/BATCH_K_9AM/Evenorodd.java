import java.io.*;
class Evenorodd
{
	public static void main(String args[])
	{
		int a=99;
		String s;

		s=(a%2==0)?"number is even":"number is odd";

		System.out.println(s);
	}
}
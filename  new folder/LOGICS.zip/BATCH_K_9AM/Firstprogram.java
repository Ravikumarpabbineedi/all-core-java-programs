import java.io.*;
class Firstprogram
{    // beginning of class
	public static void main(String a[])
	{ // beginning of main method
		System.out.println("Welcome to JAVA FULL STACK");
	} // end of main method
}// end of class
		
		

	
	
import java.io.*;
class Largestoftwo
{
	public static void main(String args[])
	{
		int a=37,b=45,largest;

		largest=(a>b)?a:b;

		System.out.println("largest of two numbers="+largest);
	}
}
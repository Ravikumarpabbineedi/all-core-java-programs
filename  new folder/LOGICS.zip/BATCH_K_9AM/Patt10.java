import java.util.*;
class Patt10
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n,i,j;

		System.out.println("enter the value of n");
		//n=sc.nextInt();

		for(i=90;i>=86;i--)
		{
			for(j=90;j>=86;j--)
				System.out.print((char)j);
			System.out.println("");
		}
	}
}
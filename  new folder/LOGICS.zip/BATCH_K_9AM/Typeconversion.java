import java.util.*;
class Typeconversion
{
	public static void main(String args[])
	{
		int b=88;

		byte a=(byte)b;

		System.out.println(a);
	}
}